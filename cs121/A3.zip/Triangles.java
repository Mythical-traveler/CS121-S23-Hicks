import java.util.Scanner;

public class Triangles {
        public static void main(String[]args) {

            int s1,s2,s3;
            Scanner console= new Scanner(System.in);
            System.out.println("Enter Length of Side One: ");
            s1=console.nextInt();
            System.out.println("Enter Length of Side Two: ");
            s2=console.nextInt();
            System.out.println("Enter Length of Side Three: ");
            s3=console.nextInt();
            if(s1==s2 && s2== s3) {
                System.out.println("You have an Equilateral Triangle.");
            }
            else if (s1==s2 || s2==s3 || s1==s3) {
                System.out.println("You have an Isosceles Triangle.");
            }
            else if (s1!=s2 && s2!=s3 && s3!=s1) {
                System.out.println("You have a Scalene Triangle.");
            }
            else if (s1<0 || s2<0 || s3<0) {
                System.out.println("Invalid Output!");
            }

            else {
                System.out.println("Invalid Output!");
            }


            }



        }


