import java.util.Scanner;
public class EvenOrOdd {
    public static void main(String[] args) {
        int num;
        Scanner console= new Scanner(System.in);
        System.out.println("Enter Number");
        num=console.nextInt();
        if (num % 2==0)
            System.out.println(num + " is an even number.");
        if (num % 2 != 0)
            System.out.println(num + " is an odd number.");

    }
}
