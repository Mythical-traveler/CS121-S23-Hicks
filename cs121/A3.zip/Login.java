import javax.swing.*;

public class Login {
    public static void main(String[]args) {
        String userName,password,name,pw;
        userName="javaclass";
        password="script";
        name= JOptionPane.showInputDialog(null,"Enter Username");
        pw=JOptionPane.showInputDialog(null, "Enter Password:");
        if (!name.equals(userName)) {
            JOptionPane.showMessageDialog(null, "Username Incorrect!");
            JOptionPane.showInputDialog(null, "Enter Username again");
        }
        else if (!pw.equals(password)) {
            JOptionPane.showMessageDialog(null, "Password Incorrect!");
            JOptionPane.showInputDialog(null, "Enter Password again");
        }
        else if ((name.equals(userName)) && (pw.equals(password))) {
            JOptionPane.showMessageDialog(null,"Welcome to CS121.");
        }
        else {
            System.out.println("Invalid Output!");
        }

        System.exit(0);

    }




        }





