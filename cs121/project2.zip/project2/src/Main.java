public class Main extends PokemonSelection {
    public static void main(String[] args) {
        PokemonSelection g = new PokemonSelection();
        g.assignPokemon();




    }
}
