public class Main {
    public static void main(String[] args) {
        sorted s = new sorted();
        int[] numbers = s.getArray();
        s.sortArray(numbers);
        }
    }

