public class Test {
    public static void main (String [] args)
    {
        BigO test=new BigO();
        test.printNSquaredTimes(4);
        test.printOnce("Test");
        test.printNTimes(4);
    }
}
