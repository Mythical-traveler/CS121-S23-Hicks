package interfaces;

public interface view {
    void viewer();
    int info();
}
