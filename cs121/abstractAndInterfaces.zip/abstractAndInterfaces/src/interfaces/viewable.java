package interfaces;

public class viewable implements view
{   int numbers = 1;

    public void viewer()
    {
        System.out.println("The Number is: "+numbers);
    }


    public int info() {
        return 0;
    }


}


