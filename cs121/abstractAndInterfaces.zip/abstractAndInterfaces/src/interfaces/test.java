package interfaces;

public class test {
    public static void main(String [] args)
    {
        viewable view= new viewable();
        view.info();
        view.viewer();
        information weiv=new information();
        weiv.viewer();
        weiv.info();

    }
}
