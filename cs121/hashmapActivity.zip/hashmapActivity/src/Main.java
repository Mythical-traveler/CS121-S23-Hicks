public class Main {
    public static void main(String[] args) {
        hashmap obj = new hashmap();
        obj.addtoHash();
        obj.removefromHash();
        obj.getValue();
        obj.display();
    }
}
